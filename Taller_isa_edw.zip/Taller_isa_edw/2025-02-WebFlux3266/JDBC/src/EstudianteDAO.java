import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {
    private Connection conn;

    public EstudianteDAO() {
        try {
            // Cambia estos datos si usas otro usuario o contraseña
            String url = "jdbc:mysql://localhost:3306/escuela?useSSL=false&serverTimezone=UTC";
            String user = "root";
            String password = "Pass_123";

            conn = DriverManager.getConnection(url, user, password);
            // Ya creaste la tabla manualmente, no necesitas crearla aquí
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean insertar(estudiante e) {
        String sql = "INSERT INTO Estudiantes(nombre, apellido, correo, edad, estado_civil) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, e.getNombre());
            stmt.setString(2, e.getApellido());
            stmt.setString(3, e.getCorreo());
            stmt.setInt(4, e.getEdad());
            stmt.setString(5, e.getEstadoCivil().name());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al insertar estudiante: " + ex.getMessage());
            return false;
        }
    }

    public boolean actualizar(estudiante e) {
        String sql = "UPDATE Estudiantes SET nombre=?, apellido=?, edad=?, estado_civil=? WHERE correo=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, e.getNombre());
            stmt.setString(2, e.getApellido());
            stmt.setInt(3, e.getEdad());
            stmt.setString(4, e.getEstadoCivil().name());
            stmt.setString(5, e.getCorreo());
            int filas = stmt.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            System.out.println("Error al actualizar estudiante: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminarPorCorreo(String correo) {
        String sql = "DELETE FROM Estudiantes WHERE correo=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, correo);
            int filas = stmt.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
            return false;
        }
    }

    public estudiante obtenerPorCorreo(String correo) {
        String sql = "SELECT * FROM Estudiantes WHERE correo=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, correo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        EstadoCivil.valueOf(rs.getString("estado_civil"))
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error al buscar estudiante: " + ex.getMessage());
        }
        return null;
    }

    public List<estudiante> obtenerTodos() {
        List<estudiante> lista = new ArrayList<>();
        String sql = "SELECT * FROM Estudiantes";
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                lista.add(new estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        EstadoCivil.valueOf(rs.getString("estado_civil"))
                ));
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener estudiantes: " + ex.getMessage());
        }
        return lista;
    }
}
