public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    UNION_LIBRE,
    DIVORCIADO;

    public static boolean esValido(String valor) {
        for (EstadoCivil e : values()) {
            if (e.name().equalsIgnoreCase(valor)) {
                return true;
            }
        }
        return false;
    }
}
