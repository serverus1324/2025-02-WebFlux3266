import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EstudianteDAO dao = new EstudianteDAO();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Insertar Estudiante");
            System.out.println("2. Actualizar Estudiante");
            System.out.println("3. Eliminar Estudiante");
            System.out.println("4. Consultar todos los estudiantes");
            System.out.println("5. Consultar Estudiante por email");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            String opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    insertar(dao, sc);
                    break;
                case "2":
                    actualizar(dao, sc);
                    break;
                case "3":
                    eliminar(dao, sc);
                    break;
                case "4":
                    consultarTodos(dao);
                    break;
                case "5":
                    consultarPorCorreo(dao, sc);
                    break;
                case "6":
                    System.out.println("👋 Saliendo del programa.");
                    return;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private static void insertar(EstudianteDAO dao, Scanner sc) {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Edad: ");
        int edad = Integer.parseInt(sc.nextLine());
        System.out.print("Estado Civil (SOLTERO, CASADO, VIUDO, UNION_LIBRE, DIVORCIADO): ");
        String estado = sc.nextLine().toUpperCase();

        if (!EstadoCivil.esValido(estado)) {
            System.out.println("Estado civil inválido.");
            return;
        }

        estudiante estudiante = new estudiante(nombre, apellido, correo, edad, EstadoCivil.valueOf(estado));
        dao.insertar(estudiante);
    }

    private static void actualizar(EstudianteDAO dao, Scanner sc) {
        System.out.print("Correo del estudiante a actualizar: ");
        String correo = sc.nextLine();
        estudiante estudiante = dao.obtenerPorCorreo(correo);

        if (estudiante == null) {
            System.out.println("Estudiante no encontrado.");
            return;
        }

        System.out.print("Nuevo Nombre: ");
        estudiante.setNombre(sc.nextLine());
        System.out.print("Nuevo Apellido: ");
        estudiante.setApellido(sc.nextLine());
        System.out.print("Nueva Edad: ");
        estudiante.setEdad(Integer.parseInt(sc.nextLine()));
        System.out.print("Nuevo Estado Civil: ");
        String estado = sc.nextLine().toUpperCase();

        if (!EstadoCivil.esValido(estado)) {
            System.out.println("Estado civil inválido.");
            return;
        }

        estudiante.setEstadoCivil(EstadoCivil.valueOf(estado));
        dao.actualizar(estudiante);
    }

    private static void eliminar(EstudianteDAO dao, Scanner sc) {
        System.out.print("Correo del estudiante a eliminar: ");
        String correo = sc.nextLine();
        if (dao.eliminarPorCorreo(correo)) {
            System.out.println("Estudiante eliminado.");
        } else {
            System.out.println("No se encontró el estudiante.");
        }
    }

    private static void consultarTodos(EstudianteDAO dao) {
        List<estudiante> lista = dao.obtenerTodos();
        if (lista.isEmpty()) {
            System.out.println("📭 No hay estudiantes.");
        } else {
            for (estudiante e : lista) {
                System.out.printf("ID: %d | %s %s | Email: %s | Edad: %d | Estado Civil: %s%n",
                        e.getId(), e.getNombre(), e.getApellido(), e.getCorreo(), e.getEdad(), e.getEstadoCivil());
            }
        }
    }

    private static void consultarPorCorreo(EstudianteDAO dao, Scanner sc) {
        System.out.print("Correo del estudiante: ");
        String correo = sc.nextLine();
        estudiante e = dao.obtenerPorCorreo(correo);
        if (e != null) {
            System.out.printf("ID: %d | %s %s | Email: %s | Edad: %d | Estado Civil: %s%n",
                    e.getId(), e.getNombre(), e.getApellido(), e.getCorreo(), e.getEdad(), e.getEstadoCivil());
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }
}
